﻿using System;
using System.Runtime.InteropServices;

namespace NarrativeProject.Rooms
{
    internal class AtticRoom : Room
    {
        internal static bool isKeyCollected;
        public static bool SilverDaggerAquired = false;


        internal override string CreateDescription()
        {                      
            if(SilverDaggerAquired)
            {
                return @"In the attic, it's dark and cold.
A chest is locked with the code [????].
You can return to your [bedroom]."; 
            }
            else
            {              
                return @"In the attic, it's dark and cold.
A chest is locked with the code [????].
You see a [knife] hanging above you, tied to a string
You can return to your [bedroom].";
            }
        }



        internal override void ReceiveChoice(string choice)
        {
            if (Bathroom.code.ToString() == choice)
            {
                Console.WriteLine("The chest opens and you get a key.");
                isKeyCollected = true;
                return;
            }
            switch (choice)
            {
                case "knife":
                    if(Bedroom.ReachStickAquired == true && SilverDaggerAquired == false )
                    {
                        Game.Allitems = Game.Allitems + 1;
                        Game.Keys.Add(KeyItem.SilverDagger);
                        Console.WriteLine("With your reach stick, you manage to catch that knife. You then realize it is not a knife, it is a silver dagger.");                      
                        SilverDaggerAquired = true;
                    }
                    else if (Bedroom.ReachStickAquired == false && SilverDaggerAquired == false)
                    {
                        Console.WriteLine("You try to catch it, but it is to high to reach it.");
                    }
                    else
                    {
                        Console.WriteLine("Invalid command.");
                    }
                    
                    break;
                case "bedroom":
                    Console.WriteLine("You return to your bedroom.");
                    Game.Transition<Bedroom>();
                    break;
                
                default:
                    Console.WriteLine("Invalid command.");
                    break;
            }
        }
    }
}
