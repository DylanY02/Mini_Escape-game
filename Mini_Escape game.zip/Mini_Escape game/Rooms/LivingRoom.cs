﻿using System;
using System.Diagnostics.Eventing.Reader;

namespace NarrativeProject.Rooms
{
    internal class LivingRoom : Room
    {
     
        public static bool FlashLightAquired = false;            
        static bool TVUsed = false;
        static int TVCode = new Random().Next(1, 4);


        internal override string CreateDescription() =>
@"You are in your living room.
Your [sofa] looks really comfy.
There's a fancy dresser with 5 drawers. [1] [2] [3] [4] [5]
You have a nice [TV].

Your [kitchen] can be seen in the back.
You can go back to your [bedroom].
There is a door, far in a corner, leading to your [basement].";

        internal override void ReceiveChoice(string choice)
        {
            if (TVCode.ToString() == choice && TVUsed == true)
            {
                Game.Keys.Add(KeyItem.DiamondRing);
                Game.Allitems = Game.Allitems + 1;             
                Console.WriteLine("You open the drawer, and find a diamond ring. You keep it with you.");                           
            }

            switch (choice) 
            {
                case "sofa":
                    Console.WriteLine("You relax on your sofa, it was indeed comfy.");
                    break;
                case "tv":
                   
                    if (TVUsed == false)
                    {                       
                        Console.WriteLine($"You sit on your sofa, and watch a good show on your TV. After that, a fortune teller tells your lucky number is {TVCode}. And you suddenly hear a noise nearby.");
                        TVUsed = true;
                    }
                    else
                    {
                        Console.WriteLine($"You sit on your sofa and keep watching various shows, thinking about about your lucky number {TVCode}");
                    }
                    break;

                case "bedroom":
                    Console.WriteLine("You enter your bedroom.");
                    Game.Transition<Bedroom>();
                    break;
                case "basement":
                    Console.WriteLine("You enter your basement.");

                    Game.Transition<Basement>();
            
                    break;
                case "1":
                    Console.WriteLine("You open the 1st drawer, there's nothing in there.");
                    break;
                case "2":
                    Console.WriteLine("You open the 2nd drawer, there's nothing in there.");
                    break;
                case "3":
                    Console.WriteLine("You open the 3rd drawer, there's nothing in there.");
                    break;
                case "4":
                    Console.WriteLine("You open the 4th drawer, there's nothing in there.");
                    break;
                case "5":

                    if(FlashLightAquired == false)
                    {
                        Game.Tools.Add(Tools.Flashlight);
                        Console.WriteLine("You open the 5th drawer, you find a flashlight and take it with you.");
                        FlashLightAquired = true;
                    }
                    else
                    {
                        Console.WriteLine("You open the 5th drawer, there's nothing else in there.");
                    }
                    break;
                case "kitchen":
                    Console.WriteLine("You go to the kitchen.");

                    Game.Transition<Kitchen>();
                    break;
                default:
                    Console.WriteLine("Invalid command.");
                    break;
         
          }
        
        }



    }
}
