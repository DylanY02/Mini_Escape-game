﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NarrativeProject.Rooms
{
    internal class MeatLocker : Room
    {
        public static bool SteakAquired = false;
        public static bool GalliumBoxAquired = false;

        internal override string CreateDescription()
        {
            if(Kitchen.BoxMelted)
            {
                return @" You find yourself in a large meat locker, it is cool in there. Meat hooked everywhere, blood dripping and it smells bad.
There are so many [steaks] in here, enough to make a buffet.
The pig's body is gone, you can see pig's bloody footprints on the ground, moving away from the worktable.
You can go back to the [kitchen].";
            }
            else
            {
               return @" You find yourself in a large meat locker, it is cool in there. Meat hooked everywhere, blood dripping and it smells bad.
You can see a dead [pig] lain on a worktable.
There are so many [steaks] in here, enough to make a buffet.";

            }
        }






        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "pig":
                    if(Kitchen.KitchenKnifeAquired && GalliumBoxAquired == false)
                    {
                        GalliumBoxAquired = true;
                        Game.Keys.Add(KeyItem.IronApple);
                        Game.Allitems = Game.Allitems + 1;
                        Console.WriteLine(@"You approach the pig's body and you see a text on the wall, written with blood :
""Open it"" 
With your knife, you proceed to cut its belly.
Guts burst through the opening and flow on the worktable.
You plunge your hands in there, you find an iron apple and a gallium box.
The box has no opening, but can be easily melted. You take these with you");
                    }
                    else if(GalliumBoxAquired == true && Kitchen.BoxMelted == false)
                    {
                        Console.WriteLine("You approach the butchered pig's body, there is nothing else to do.");
                    }
                    else if(GalliumBoxAquired == true && Kitchen.BoxMelted == true)
                    {
                        Console.WriteLine("Invalid command.");
                    }
                    else
                    {
                        Console.WriteLine(@"You approach the pig's body and you see a text on the wall, written with blood :
""Open it""");

                    }
                    break;
                case "steaks":
                    if(SteakAquired)
                    {
                        Console.WriteLine("You already have a steak with you. You can't bring more.");
                    }
                    else
                    {
                        SteakAquired = true;
                        Console.WriteLine("You take a steak with you, it looks delicious.");
                    }
                    break;
                case "kitchen":
                    Console.WriteLine("You go back to the kitchen.");

                    Game.Transition<Kitchen>();
                    break;
                default:
                    Console.WriteLine("Invalid command.");
                    break;


            }
         
   


                
        }



    }
}
