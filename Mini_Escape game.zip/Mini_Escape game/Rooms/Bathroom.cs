﻿using System;

namespace NarrativeProject.Rooms
{
    internal class Bathroom : Room
    {
        bool isBathUsed = false;
        public static int code = new Random().Next(1000, 9000);
        

        internal override string CreateDescription() =>
@"In your bathroom, the [bath] is filled with hot water.
You can wash your body with [soap].
The [mirror] in front of you reflects your depressed face.
You can return to your [bedroom].
";

        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "bath":
                    if(isBathUsed == false)
                    {
                        Game.Keys.Add(KeyItem.GoldenEgg);
                        Game.Allitems = Game.Allitems + 1;
                        Console.WriteLine("You relax in the bath. But you feel something weird touching your back... It's a golden egg ! You take it with you.");
                        isBathUsed = true;                    
                    }
                    else
                    {
                        Console.WriteLine("You relax in the bath.");
                    }                                      
                    break;
                case "soap":                  
                    Console.WriteLine("You wash your body with soap");                   
                    break;
                case "mirror":
                    if (isBathUsed)
                    {
                        Console.WriteLine($"You see the numbers {code} written on the fog on your mirror.");
                    }
                    else
                    {
                        Console.WriteLine("You cannot see anything of interest in the mirror.");
                    }
                    break;
                case "bedroom":
                    Console.WriteLine("You return to your bedroom.");
                    Game.Transition<Bedroom>();
                    break;
                default:
                    Console.WriteLine("Invalid command.");
                    break;
                  
            }
        }
    }
}
