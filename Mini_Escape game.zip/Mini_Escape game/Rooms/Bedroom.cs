﻿using System;

namespace NarrativeProject.Rooms
{
    internal class Bedroom : Room
    {

        public static bool ReachStickAquired = false;

        internal override string CreateDescription()
        {
            if(Game.Allitems == 8)
            {
                return @"You are in your bedroom.

Your [closet] contains all your clothes.
Your super expensive gaming [pc] is on your desk.
Your [bed] next to you.

A mysterious [portal] is opened right in the middle of the room.

The [door] in front of you leads to your living room.
Your private [bathroom] is to your left.
From your closet, you see the [attic].
";
            }
            else
            {
                return @"You are in your bedroom.

Your [closet] contains all your clothes.
Your super expensive gaming [pc] is on your desk.
Your [bed] next to you.

The [door] in front of you leads to your living room.
Your private [bathroom] is to your left.
You can enter the [attic].
";
            }
        }


        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "portal":
                    if(Game.Allitems == 8)
                    {
                        (Game.isFinished) = true;
                        Console.WriteLine("You enter the portal. And you wake up from this weird dream, where you had to collect specific items in your house.");
                                         
                    }
                    else
                    {
                        Console.WriteLine("Invalid command");
                    }
                    break;
                
                case "closet":
                    if(Basement.CrowbarAquired)
                    {
                        Game.Keys.Add(KeyItem.SteelTalon);
                        Game.Tools.Add(Tools.ReachStick);
                        Game.Allitems = Game.Allitems + 1;
                        ReachStickAquired = true;
                        Console.WriteLine("With your crowbar, you force open your closet. Revealing a steel talon and a reach stick, you take these with you.");
                    }
                    else
                    {
                        Console.WriteLine("You try to open your closet but it's stuck ! You might need a tool for that.");                      
                    }  
                    break;
                case "pc":
                    Console.WriteLine("You sit down in front of your desk and start playing for hours... until you remember you have something to do.");
                    break;
                case "bed":
                    Console.WriteLine("You jump on your bed and take a good nap... no wait that's not the time !");
                    break;
                case "bathroom":
                    Console.WriteLine("You enter the bathroom.");
                    Game.Transition<Bathroom>();
                    break;
                case "door":
                    if (!AtticRoom.isKeyCollected)
                    {
                        Console.WriteLine("The door is locked.");
                    }
                    else
                    {
                        Console.WriteLine("You open the door with the key and enter the living room.");
                       Game.Transition<LivingRoom>();
                    }
                    break;
                case "attic":
                    Console.WriteLine("You go up and enter your attic.");
                    Game.Transition<AtticRoom>();
                    break;
                default:
                    Console.WriteLine("Invalid command.");
                    break;
                  
            }
        }
    }
}
