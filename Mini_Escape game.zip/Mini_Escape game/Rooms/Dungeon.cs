﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NarrativeProject.Rooms
{
    internal class Dungeon : Room
    {
        static bool Feeded = false;
        internal override string CreateDescription() =>
@"You enter a dungeon. The room is big, and the walls are painted in red, it is dark in here. There are torture devices everywhere. You feel completely scared.

You spot a terrifying [creature] inside a large cage.

You can go back to the [basement].
";

        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "creature":
                    if (MeatLocker.SteakAquired)
                    {
                        Game.Keys.Add(KeyItem.BlackTeeth);
                        Game.Allitems = Game.Allitems + 1;
                        Feeded = true;
                        Console.WriteLine(@"The four-legged creature stares at you, in complete silence, drooling.
It looks like it is starving.
You toss your fresh steak in the cage, the creature jump on it and devour it, before spitting a black teeth out of the cage.
You pick the black teeth from the ground.");
                    }
                    else if(Feeded == true)
                    {
                        Console.WriteLine("It is now sleeping, better leave it alone now.");
                    }
                    else
                    {
                        Console.WriteLine(@"The four-legged creature stares at you, in complete silence, drooling.
It looks like it is starving.");
                    }
                    break;

                case "basement":
                    Console.WriteLine("You go back to your basement.");

                    Game.Transition<Basement>();
                    break;

                default:
                    Console.WriteLine("Invalid command.");
                    break;
            }

        }
    }
}
