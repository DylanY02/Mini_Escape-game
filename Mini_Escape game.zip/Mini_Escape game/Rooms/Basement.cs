﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NarrativeProject.Rooms
{
    internal class Basement : Room
    {           
        public static bool CrowbarAquired = false;
        static bool WoodenMaskAquired = false;
        public static bool Allitems = false;
        internal override string CreateDescription()
        {
            if (LivingRoom.FlashLightAquired)
            {
                return @"You enter your basement, flashlight in hand, you can see clearly in this darkness.
You can see the [light switch] next to you.
There is a large [box].
A tiny [chest] on a broken dresser catch your attention.

A strange dark [door] is far in the back.
You can go back to your [living room];";
            }
            else
            {
                return @"You enter your basement, it is very dark in here, you can't see anything.
You can barely see the [light switch] next to you";
            }
        }




        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "light switch":
                    
                    if(LivingRoom.FlashLightAquired)
                    {
                        Console.WriteLine("The light switch doesn't work, keep using your flashlight.");
                    }
                    else
                    {
                        Console.WriteLine("The light switch doesn't work, there must be a way to illuminate your way...");
                    }
                    break;
                case "box":
                    if(LivingRoom.FlashLightAquired)
                    {
                        Game.Tools.Add(Tools.Crowbar);
                        CrowbarAquired = true;
                        Console.WriteLine("You check what is inside, and you find a crowbar. You take it with you, it might be useful.");
                    }
                    else if (CrowbarAquired == true)
                    {
                        Console.WriteLine("The box is now empty.");
                    }
                    else
                    {
                        Console.WriteLine("Invalid command.");
                    }
                    break;
                case "chest":
                    if(LivingRoom.FlashLightAquired && AtticRoom.SilverDaggerAquired)
                    {
                        Game.Keys.Add(KeyItem.WoodenMask);
                        WoodenMaskAquired = true;
                        Game.Allitems = Game.Allitems + 1;
                        Console.WriteLine(@"You use the silver dagger to open the chest, and you find a strange wooden mask, you take it with you.");                       
                         
                    }
                    else if (LivingRoom.FlashLightAquired && AtticRoom.SilverDaggerAquired == false)
                    {
                        Console.WriteLine("You check the chest. It is locked. Weird, the lock is very thin for a key... maybe a knife ?");
                    }
                    else if(LivingRoom.FlashLightAquired && Kitchen.KitchenKnifeAquired && AtticRoom.SilverDaggerAquired == false)
                    {
                        Console.WriteLine("You try your kitchen knife, but it doesn't fit.");
                    }
                    else if (WoodenMaskAquired == true)
                    {
                        Console.WriteLine("The chest is empty");
                    }
                    else
                    {
                        Console.WriteLine("Invalid command.");
                    }
                    break;
                case "door":
                    if (WoodenMaskAquired)
                    {                       
                        Console.WriteLine(@"The wooden mask starts to vibrate when approaching the door, you take it in your hands and present it.
                                          The door open on its own, you enter inside, and you find yourself in a dungeon.");
                        Game.Transition<Dungeon>();
                    }
                    else
                    {
                        Console.WriteLine("This door is locked, you don't remember it being there. There is a pattern on the door that looks like a mask. Strange.");
                    }

                    break;
                case "living room":
                    Console.WriteLine("You enter your living room.");
                    Game.Transition<LivingRoom>();
                    break;

                default:
                    Console.WriteLine("Invalid command.");
                    break;

            }


        }
    }
}
