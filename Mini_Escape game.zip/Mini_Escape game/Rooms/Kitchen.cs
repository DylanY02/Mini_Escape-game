﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NarrativeProject.Rooms
{
    internal class Kitchen : Room
    {
        public static bool KitchenKnifeAquired = false;
        public static bool BoxMelted = false;
        static int snacks = 3;

        internal override string CreateDescription()
        {
            if (KitchenKnifeAquired)
            {
                return @"You are now in the kitchen, suited for a chef.
The [oven] can be used to cook food.
Or you can use the [stove].
There's your [fridge] next to the stove.

A door next to the fridge lead to the [meat locker].
Or go back in the [living loom].
";
            }
            else
            {
                return @"You are now in the kitchen, suited for a chef.
The [oven] can be used to cook food.
Or you can use the [stove].
A [kitchen knife] is on the table.
There's your [fridge] next to the stove.

A door next to the fridge lead to the [meat locker].
Or go back in the [living loom].
";
            }
        }


        internal override void ReceiveChoice(string choice)
        {
            switch (choice)
            {
                case "oven":
                    if(MeatLocker.GalliumBoxAquired)
                    {
                        Game.Allitems = Game.Allitems + 1;
                        Game.Keys.Add(KeyItem.TungstenBadge);
                        BoxMelted = true;
                        Console.WriteLine(@"You put the gallium box inside the oven and heat it at high temperature.
The box melt and reveal a tungsten badge, you turn off the oven, and you take it with you once it cools down.");
                    }
                    else
                    {
                        Console.WriteLine("You have nothing to bake.");
                    }                   
                    break;
                case "stove":
                    if(MeatLocker.SteakAquired)
                    {
                        Game.hp = Game.hp + 5;
                        Console.WriteLine("You cook your delicious steak then eat it, it restores 5 HP.");
                        MeatLocker.SteakAquired = false;
                    }
                    else
                    {
                        Console.WriteLine("You have nothing to cook.");
                    }                   
                    break;
                case "fridge":
                    if (snacks > 0) // Check if there are snacks available
                    {
                        Game.hp = Game.hp + 1; // Restore 1 HP
                        Console.WriteLine("You grab a snack and eat it. It restores 1 HP.");
                        snacks--; // Decrement the snacks count
                        Console.WriteLine("Your fridge now has " + snacks + " snack(s) left.");
                    }
                    else
                    {
                        Console.WriteLine("Your fridge is empty.");
                    }
                    break;
                case "kitchen knife":
                    if(KitchenKnifeAquired == false)
                    {
                        Game.Tools.Add(Tools.KitchenKnife);
                        KitchenKnifeAquired = true;
                        Console.WriteLine("This knife is very sharp. You take take it with you.");
                    }
                    else
                    {
                        Console.WriteLine("Invalid command.");
                    }
                    break;
                case "living room":
                    {
                        Console.WriteLine("You enter your living room.");
                        Game.Transition<LivingRoom>();
                        break;
                    }
                case "meat locker":
                    {
                        Console.WriteLine("You enter the meat locker.");
                        Game.Transition<MeatLocker>();
                        break;
                    }
                default:
                    Console.WriteLine("Invalid command.");
                    break;
            }

        }


    }
}
