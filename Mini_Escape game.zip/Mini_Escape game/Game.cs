﻿using NarrativeProject.Rooms;
using System;
using System.Collections.Generic;
using System.Runtime.ExceptionServices;

namespace NarrativeProject
{
    public enum KeyItem
    {
        GoldenEgg,
        WoodenMask,
        SteelTalon,
        SilverDagger,
        DiamondRing,
        IronApple,
        TungstenBadge,
        BlackTeeth,
    }

    public enum Tools
    {
        Flashlight,
        Crowbar,
        ReachStick,
        KitchenKnife, 
    }

    internal class Game
    {
        public static int Allitems = 0;
        public static int hp = 100;
        static string[] GameOver = {"You died", "you have perished", "The game has ended", "Game Over", "You got annihilated"};

        List<Room> rooms = new List<Room>();

        public static List<KeyItem> Keys = new List<KeyItem>(); 
        public static List<Tools> Tools= new List<Tools>();
        Room currentRoom;
        internal bool IsGameOver() => isFinished;
        public static bool isFinished;
        static string nextRoom = "";

        

        

        internal void Add(Room room)
        {
            rooms.Add(room);
            if (currentRoom == null)
            {
                currentRoom = room;
            }
        }

        internal string CurrentRoomDescription => currentRoom.CreateDescription();

        internal void ReceiveChoice(string choice)
        {
            currentRoom.ReceiveChoice(choice);
            CheckTransition();
        }

        internal static void Transition<T>() where T : Room
        {
            nextRoom = typeof(T).Name;

            if (hp > 0)
            {
                int index = new Random().Next(1, 3);
                Console.WriteLine("You have " + hp + " HP left");
                hp = hp - index;
            }
            else
            {
                int index = new Random().Next(0, GameOver.Length);
                Console.WriteLine(Game.GameOver[index]);
                isFinished = true;
            }

            if(Allitems == 8)
            {
                Console.WriteLine("You hear a strange noise coming from your bedroom.");
            }
        }

        internal static void Finish()
        {
            isFinished = true;
        }

        internal void CheckTransition()
        {
            foreach (var room in rooms)
            {
                if (room.GetType().Name == nextRoom)
                {
                    nextRoom = "";
                    currentRoom = room;
                    break;
                }
            }
        }
    }
}
